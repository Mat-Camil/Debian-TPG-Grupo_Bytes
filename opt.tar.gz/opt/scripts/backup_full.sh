#!/bin/bash

help(){
echo "Descripcion del script:"
echo "Descripcion del script:"
echo ""
echo "Este script genera backups de un directorio."
echo ""
echo "Modo de uso:"
echo ""
echo "backup_full.sh"
echo ""
echo "Se ingresa el origen."
echo ""
echo "Se verifica si existe."
echo ""
echo "Se pide el destino."
echo ""
echo ""
echo "TODOS LOS DÍAS a las 00:00 se Backupeara el directorio: “/var/logs”."
echo ""
echo "Los LUNES, MIÉRCOLES, VIERNES a las 23:00 se Backupeara el directorio:  “/www_dir”"
echo ""
}

ca=1

for arg in "$@"
do
        if [ "$arg" = "--help" ] || [ "$arg" = "-h" ]
        then
                ca=0
        fi
done



case $ca in 
 0)
	help
	;;
 1)

	ORIGEN=$1

	if [ -d "$ORIGEN" ]
	then
		DESTINO=$2
	
		if [ -z $DESTINO ] 
		then
			DESTINO="/backup_dir"
		fi

		if [ -d $DESTINO ]
		then
			NOMBRE_BACK=$DESTINO
			NOMBRE_BACK+="/"
			NOMBRE_BACK+=$(basename "$ORIGEN")
			NOMBRE_BACK+="_bkp_"
			NOMBRE_BACK+="$(date '+%Y%m%d')"
			NOMBRE_BACK+=".tar.gz"

			tar -czvf "$NOMBRE_BACK" $ORIGEN*
		else 	
			echo "El directorio destino no existe"
		fi
	else 
		echo "El directorio origen no existe."
	fi
;;
esac
